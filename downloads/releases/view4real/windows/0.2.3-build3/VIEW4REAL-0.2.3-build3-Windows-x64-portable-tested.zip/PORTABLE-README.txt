View4Real 0.2.3 / Build 3 - WINDOWS PORTABLE TEST BUILD

Extract the entire ZIP, then open VIEW4REAL.exe. No app installer, administrator
permission, registry startup entry, account or subscription is required.

Prerequisite: Microsoft Edge WebView2 Runtime must already be present on
Windows. If it is missing, this package does not silently install it. Use the
browser-based optical lab or have your system administrator install Microsoft's
official runtime. Do not disable Windows protections to run this app.

Check BUILD-MANIFEST.json for the exact source commit, SHA-256 and signing status.
Unsigned files may produce SmartScreen or antivirus warnings. Signing also does
not guarantee that every Windows protection will allow an app. No warning-free
claim is made. No bypass instructions are included.

The reader changes only its own text size, spacing, width and colors. Windows
brightness is an explicit optional action, limited to one supported internal
monitor and confirmed by read-back. Unsupported/multiple displays are left
alone. Restore original brightness before closing if desired. App exit does not
automatically restore hardware brightness. No system-wide prescription filter,
screen capture, DDC/CI, OCR, or correction of other applications is provided.

No login or password. Text stays in memory. Remembering comfort preferences is
optional. WebView2/browser caches may persist in the normal user profile.
Portable means no app installer, not no disk traces or encrypted local storage.
The Privacy screen can clear VIEW4REAL preferences and old prototype login data.

The sandboxed optical lab is experimental. Numerical accuracy is not proof of
human vision improvement. It cannot replace prescribed eyewear or professional
eye care. Stop if discomfort occurs. No clinical benefit has been demonstrated.

Subscriptions are not connected in this build. Monthly/annual server contracts
are test-mode only. No charges, secret payment keys or fake paid unlocks exist.
The product's working name remains subject to clearance before sale.

Open Update history inside the app for version, build, Eastern preparation time
and descriptions. BUILD-MANIFEST.json records the native build and package times.
TEST-RESULTS.json, when supplied, describes checks of this exact executable.
